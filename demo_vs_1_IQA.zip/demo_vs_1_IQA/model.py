import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torchsummary import summary
from torchvision import models

class ResidualBlock(nn.Module):
    """Residual Block with instance normalization."""
    def __init__(self, dim_in, dim_out):
        super(ResidualBlock, self).__init__()
        self.main = nn.Sequential(
            nn.Conv2d(dim_in, dim_out, kernel_size=3, stride=1, padding=1, bias=False),
            nn.InstanceNorm2d(dim_out, affine=True, track_running_stats=True),
            nn.ReLU(inplace=False),
            nn.Conv2d(dim_out, dim_out, kernel_size=3, stride=1, padding=1, bias=False),
            nn.InstanceNorm2d(dim_out, affine=True, track_running_stats=True))

    def forward(self, x):
        return x + self.main(x)


class ImageBlock(nn.Module):
    """ImageBlock for conversion."""
    def __init__(self, dim_in, dim_out, _stride):
        super(ImageBlock, self).__init__()
        self.main_vec = nn.Sequential(
            nn.Conv2d(dim_in, dim_out, kernel_size=3, stride=_stride, padding=1, bias=False),
            nn.Tanh())

    def forward(self, x):
        return self.main_vec(x)


class Generator(nn.Module):
    """Generator network."""

    def __init__(self, conv_dim=64, c_dim=5, repeat_num=6):
        super(Generator, self).__init__()
        self.style_loss = Style_Loss()

        # Create sub-layer pipelines for downscaled analysis
        layers = []
        layers_1 = []
        layers_2 = []
        layers_3 = []
        layers_4 = []

        layers.append(nn.Conv2d(3+c_dim, conv_dim, kernel_size=7, stride=1, padding=3, bias=False))
        layers.append(nn.InstanceNorm2d(conv_dim, affine=True, track_running_stats=True))
        layers.append(nn.ReLU(inplace=False))

        ########################################################
        #                   Down-sampling layers               #
        ########################################################

        curr_dim = conv_dim
        self.cur_dim = None

        for i in range(1):
            layers.append(nn.Conv2d(curr_dim, curr_dim*2, kernel_size=4, stride=2, padding=1, bias=False))
            layers.append(nn.InstanceNorm2d(curr_dim*2, affine=True, track_running_stats=True))
            layers.append(nn.ReLU(inplace=False))
            curr_dim = curr_dim * 2
            self.cur_dim = curr_dim
        self.main_vec_0 = nn.Sequential(*layers)

        # To image format
        layers_x = [ImageBlock(dim_in=self.cur_dim, dim_out=c_dim+3, _stride=1)]
        self.main_chl_0 = nn.Sequential(*layers_x)

        for i in range(1):
            layers_1.append(nn.Conv2d(curr_dim, curr_dim*2, kernel_size=4, stride=2, padding=1, bias=False))
            layers_1.append(nn.InstanceNorm2d(curr_dim*2, affine=True, track_running_stats=True))
            layers_1.append(nn.ReLU(inplace=False))
            curr_dim = curr_dim * 2
            self.cur_dim = curr_dim
        self.main_vec_1 = nn.Sequential(*layers_1)
        layers_x = [ImageBlock(dim_in=self.cur_dim, dim_out=c_dim + 3,  _stride=1)]
        self.main_chl_1 = nn.Sequential(*layers_x)

        ########################################################
        #                   Bottleneck layers                  #
        ########################################################

        # Extract Features for 1st resolution point  | */2 | 128 channels | 2 Res blocks
        for i in range(repeat_num):
            layers_2.append(ResidualBlock(dim_in=self.cur_dim, dim_out=self.cur_dim))
        self.main_vec_2 = nn.Sequential(*layers_2)

        # To image format
        layers_x = [ImageBlock(dim_in=self.cur_dim, dim_out=c_dim+3, _stride=2)]
        self.main_chl_2 = nn.Sequential(*layers_x)

        ########################################################
        #                  FC layers                           #
        ########################################################

        for i in range(2):
            layers_4.append(nn.ReLU(inplace=False))
            layers_4.append(nn.Conv2d(curr_dim, curr_dim//2, kernel_size=2, stride=2, padding=0, bias=False))
            layers_4.append(nn.InstanceNorm2d(curr_dim//2, affine=True, track_running_stats=True))
            layers_4.append(nn.ReLU(inplace=False))
            curr_dim = curr_dim // 2
            self.cur_dim = curr_dim

        self.main_vec_3 = nn.Sequential(*layers_4)
        layers_x = [ImageBlock(dim_in=self.cur_dim, dim_out=c_dim + 3,  _stride=2)]
        self.main_chl_3 = nn.Sequential(*layers_x)

        layers_fc = [nn.Linear(8192, 8192), nn.Linear(8192, 4096)]
        # layers_fc = [nn.Linear(32768, 8192), nn.Linear(8192, 4096)]
        self.fc = nn.Sequential(*layers_fc)

        ########################################################
        #                   Up-sampling layers                 #
        ########################################################

        self.cur_dim = curr_dim * 32
        print(self.cur_dim)

        for i in range(8):
            layers_3.append(nn.ConvTranspose2d(self.cur_dim, self.cur_dim//2, kernel_size=4, stride=2,
                                               padding=1, bias=False))
            layers_3.append(nn.InstanceNorm2d(self.cur_dim//2, affine=True, track_running_stats=True))
            layers_3.append(nn.ReLU(inplace=False))
            self.cur_dim = self.cur_dim // 2
            print(self.cur_dim)

        print(self.cur_dim)
        print("self.cur_dim")
        # exit()
        layers_3.append(nn.Conv2d(self.cur_dim, c_dim+3, kernel_size=4, stride=2, padding=1, bias=False))
        layers_3.append(nn.Tanh())
        self.main = nn.Sequential(*layers_3)

    def forward(self, x, c):

        # Get shape of image
        n, c, h, w = [*x.shape]
        b_sz = n
        # print(n)

        # Extract features at defined nodes #
        # Node 1
        print(x.shape)
        x = self.main_vec_0(x)
        x_0 = self.main_chl_0(x)
        print(x.shape)
        print(x_0.shape)

        # Node 2
        x = self.main_vec_1(x)
        x_1 = self.main_chl_1(x)
        print(x.shape)

        # Node 3
        x = self.main_vec_2(x)
        x_2 = self.main_chl_2(x)

        # Node 4
        x = self.main_vec_3(x)
        x_3 = self.main_chl_3(x)
        print(x_3.shape)

        # FC and shaping #
        x = x.view(-1)
        x = self.fc(x)
        print("x.shape")
        print(x.shape)


        fc_x = x
        sz = [*x.shape][0]
        x = x.view(b_sz, sz//b_sz, 1, 1)
        print(x.shape)


        # Transposing
        x = self.main(x)
        print(x.shape)
        # exit()
        # Check Model Arch
        # print(self.main_vec_0)
        # print(self.main_vec_1)
        # print(self.main_vec_2)
        # print(self.main)

        # exit()
        return x, x_0, x_1, x_2, fc_x


class Discriminator(nn.Module):
    """ Discriminator network """
    def __init__(self, image_size=64, conv_dim=64, c_dim=5, repeat_num=5):

        super(Discriminator, self).__init__()
        layers = [nn.Conv2d(3 + c_dim, conv_dim, kernel_size=4, stride=2, padding=1), nn.LeakyReLU(0.01)]
        curr_dim = conv_dim

        for i in range(1, repeat_num):
            layers.append(nn.Conv2d(curr_dim, curr_dim*2, kernel_size=4, stride=2, padding=1))
            layers.append(nn.LeakyReLU(0.01))
            curr_dim = curr_dim * 2

       # conv_dim = 1024
        kernel_size = int(image_size / np.power(2, repeat_num))
        self.main = nn.Sequential(*layers)

        # self.main.to("cuda")
        self.conv1 = nn.Conv2d(curr_dim, 1, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv2 = nn.Conv2d(curr_dim, c_dim, kernel_size=kernel_size, bias=False)

    def forward(self, x):

        N, C, H, W = x[:, 3:, :, :].shape
        x_chl = x[:, 3:, :, :]

        #  Get outputs for 3 channel and c_dim channels separately #
        print(" C C C C ")
        print(x.shape)
        h = self.main(x)

        out_src = self.conv1(h)
        out_cls = self.conv2(h)

        # out_cls = out_cls.view(out_cls.size(0), out_cls.size(1))

        # Get mean of each map channel
        # x_mean = x_chl.view(N, C, H*W)
        # chl_means = torch.mean(x_mean, dim=[2])
        chl_means = x_chl  # sim loss computed at main.py

        # print("chl_means.shape")
        # print(chl_means.shape)
        # print(out_src.shape)
        # print(out_cls.shape)
        # exit()

        print("Disc activated")
        return out_src, out_cls, chl_means

class VGGLoss(nn.Module):
    """ VGG loss - perceptual """
    def __init__(self, start_lay):
        super(VGGLoss, self).__init__()
        self.criterion = nn.L1Loss()
        self.weights = [1.0/32, 1.0/16, 1.0/8, 1.0/4, 1]

        self.start_lay = start_lay

    def forward(self, x_vgg, x_rec_vgg):
        loss = (self.weights[self.start_lay]) * \
               self.criterion(x_rec_vgg[self.start_lay], x_vgg[self.start_lay].detach())
        return loss


class Vgg19(nn.Module):
    """ VGG 19 pre-trained model """
    def __init__(self, requires_grad=False):
        super(Vgg19, self).__init__()
        vgg_pretrained_features = models.vgg19(pretrained=True).features
        self.slice1 = torch.nn.Sequential()
        self.slice2 = torch.nn.Sequential()
        self.slice3 = torch.nn.Sequential()
        self.slice4 = torch.nn.Sequential()
        self.slice5 = torch.nn.Sequential()
        for x in range(2):#2
            self.slice1.add_module(str(x), vgg_pretrained_features[x])
        for x in range(2, 7):#5
            self.slice2.add_module(str(x), vgg_pretrained_features[x])
        for x in range(7, 12):#5
            self.slice3.add_module(str(x), vgg_pretrained_features[x])
        for x in range(12, 21):#9
            self.slice4.add_module(str(x), vgg_pretrained_features[x])
        for x in range(21, 30):#9
            self.slice5.add_module(str(x), vgg_pretrained_features[x])
        if not requires_grad:
            for param in self.parameters():
                param.requires_grad = False

    def forward(self, x, c):

        x = x[:, :3, :, :]
        # N, C, H, W = x[:, 3:, :, :].shape

        h_relu1 = self.slice1(x)
        h_relu2 = self.slice2(h_relu1)
        h_relu3 = self.slice3(h_relu2)
        h_relu4 = self.slice4(h_relu3)
        h_relu5 = self.slice5(h_relu4)
        # X = h_relu5

        # c = c.view(c.size(0), c.size(1), 1, 1)
        # c = c.repeat(1, 1, X.size(2), X.size(3))
        # X = torch.cat([X, c], dim=1)

        out = h_relu4
        # out = [h_relu1, h_relu2, h_relu3, h_relu4, X ]
        return out

def gram_matrix(tensor):
    """ Compute Gram Matrix"""
    #  depth, height, and width
    b, d, h, w = tensor.size()
    print(b, d, h, w)
    tensor = tensor.view(b*d, h * w)
    # tensor = torch.flatten(tensor)
    gram = torch.mm(tensor, tensor.t())
    return gram.div(b * d * h * w)

def gram_matrix_1(tensor):
    """ Compute Gram Matrix"""
    # depth, height, and width

    d, h, w = tensor.size()
    tensor = tensor.reshape(d, h * w)
    gram = torch.mm(tensor, tensor.t())
    return gram.div(d * h * w)

class Style_Loss(nn.Module):
    """Style Loss"""
    def __init__(self):
        super(Style_Loss, self).__init__()
        self.criterion = nn.L1Loss()

    def forward(self, x_vgg, x_rec_vgg):
        style_loss = 0
        for i in range(len(x_vgg)):
            gram_x_rec = gram_matrix(x_rec_vgg)
            style_grams = gram_matrix(x_vgg)
            layer_style_loss = torch.mean(torch.abs(self.criterion(style_grams, gram_x_rec)))
            style_loss += layer_style_loss

        return style_loss


class Style_Loss_1(nn.Module):
    """Style Loss"""
    def __init__(self):
        super(Style_Loss_1, self).__init__()
        self.criterion = nn.L1Loss()

    def forward(self, x_vgg, x_rec_vgg):
        style_loss = 0
        # b, d, h, w = x_vgg.size()
        print(x_vgg.shape)
        for i in range(len(x_vgg)):
            print(i)
            print(x_vgg[i].shape)
            print(x_rec_vgg[i].shape)
            gram_x_rec  = gram_matrix_1(x_rec_vgg[i])
            style_grams = gram_matrix_1(x_vgg[i])
            layer_style_loss = torch.mean(torch.abs(self.criterion(style_grams, gram_x_rec)))
            style_loss += layer_style_loss
        return style_loss

