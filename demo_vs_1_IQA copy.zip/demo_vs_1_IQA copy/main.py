import os
import argparse
from solver_9 import Solver
from data_loader import get_loader
from data_loader_gui import get_loader_gui
# from torch.backends import cudnn
import sps_GUI as sps
import os, ssl

if (not os.environ.get('PYTHONHTTPSVERIFY', '') and
    getattr(ssl, '_create_unverified_context', None)):
    ssl._create_default_https_context = ssl._create_unverified_context

def str2bool(v):
    return v.lower() in ('true')

def main(config):
    # For fast training.
    # cudnn.benchmark = True

    # Create directories if not exist.
    if not os.path.exists(config.log_dir):
        os.makedirs(config.log_dir)
    if not os.path.exists(config.model_save_dir):
        os.makedirs(config.model_save_dir)
    if not os.path.exists(config.sample_dir):
        os.makedirs(config.sample_dir)
    if not os.path.exists(config.result_dir):
        os.makedirs(config.result_dir)

    # Data loader.
    celeba_loader = None
    celeba_loader_skt = None
    cgui_loader_skt = None
    rafd_loader = None
    dataX = None
    dataY = None
    gui_Y = None

    if config.dataset in ['CelebA', 'Both']:

        # cgui_loader_skt          = get_loader_gui(config.cgui_image_dir_skt, config.attr_path,config.selected_attrs,
        #                                          config.image_size, config.batch_size,
        #                                         'CelebA', config.mode, config.num_workers)
        # exit()
        celeba_loader, dataX     = get_loader(config.celeba_image_dir, config.attr_path, config.selected_attrs,
                                   config.celeba_crop_size, config.image_size, config.batch_size,
                                   'CelebA', config.mode, config.num_workers)

        celeba_loader_skt, dataY = get_loader(config.celeba_image_dir_skt, config.attr_path, config.selected_attrs,
                                   config.celeba_crop_size, config.image_size, config.batch_size,
                                   'CelebA', config.mode, config.num_workers)


    if config.dataset in ['RaFD', 'Both']:
        rafd_loader = get_loader(config.rafd_image_dir, None, None,
                                 config.rafd_crop_size, config.image_size, config.batch_size,
                                 'RaFD', config.mode, config.num_workers)

    # Solver for training and testing .
    solver = Solver(celeba_loader, celeba_loader_skt, cgui_loader_skt, rafd_loader, config, dataX, dataY)

    if config.mode == 'train':
        if config.dataset in ['CelebA', 'RaFD']:
            solver.train()
    elif config.mode == 'test':
        if config.dataset in ['CelebA', 'RaFD']:
            solver.test()
    elif config.mode == 'test_gui':
        if config.dataset in ['CelebA', 'RaFD']:
            sps.vp_start_gui(solver)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    # Model configuration.
    parser.add_argument('--c_dim', type=int, default=5, help='dimension of domain labels (1st dataset)')
    parser.add_argument('--c2_dim', type=int, default=5, help='dimension of domain labels (2nd dataset)')
    parser.add_argument('--celeba_crop_size', type=int, default=220, help='crop size for the CelebA dataset')
    parser.add_argument('--rafd_crop_size', type=int, default=229, help='crop size for the RaFD dataset')
    parser.add_argument('--image_size', type=int, default=256, help='image resolution')
    parser.add_argument('--g_conv_dim', type=int, default=64, help='number of conv filters in the first layer of G')
    parser.add_argument('--d_conv_dim', type=int, default=64, help='number of conv filters in the first layer of D')
    parser.add_argument('--g_repeat_num', type=int, default=6, help='number of residual blocks in G')
    parser.add_argument('--d_repeat_num', type=int, default=6, help='number of strided conv layers in D')
    parser.add_argument('--lambda_cls', type=float, default=1, help='weight for domain classification loss')
    parser.add_argument('--lambda_rec', type=float, default=100, help='weight for reconstruction loss  [10]')
    parser.add_argument('--lambda_gp', type=float, default=5, help='weight for gradient penalty [10]')
    
    # Training configuration.
    parser.add_argument('--dataset', type=str, default='CelebA', choices=['CelebA', 'RaFD', 'Both'])
    parser.add_argument('--batch_size', type=int, default=2, help='mini-batch size')
    parser.add_argument('--num_iters', type=int, default=10000000, help='number of total iterations for training D')
    parser.add_argument('--num_iters_decay', type=int, default=100000, help='number of iterations for decaying lr')
    parser.add_argument('--g_lr', type=float, default=0.000002, help='learning rate for G')
    parser.add_argument('--d_lr', type=float, default=0.00002, help='learning rate for D')
    parser.add_argument('--n_critic', type=int, default=10, help='number of D updates per each G update')
    parser.add_argument('--beta1', type=float, default=0.8, help='beta1 for Adam optimizer')
    parser.add_argument('--beta2', type=float, default=0.999, help='beta2 for Adam optimizer')
    parser.add_argument('--resume_iters', type=int, default=None, help='resume training from this step')
    parser.add_argument('--selected_attrs', '--list', nargs='+', help='selected attributes for the CelebA dataset',
                        default=['Black_Hair', 'Blond_Hair', 'Brown_Hair', 'Male', 'Young'])

    # Test configuration.
    parser.add_argument('--test_iters', type=int, default=1570000, help='test model from this step')
    #153
    # Miscellaneous.
    parser.add_argument('--num_workers', type=int, default=0)
    parser.add_argument('--limit', type=int, default=4)
    parser.add_argument('--mode', type=str, default='train', choices=['train', 'test', 'test_gui'])
    parser.add_argument('--use_tensorboard', type=str2bool, default=True)

    # Directories.
    parser.add_argument('--celeba_image_dir', type=str, default='/Users/ucheosahor/Documents/Data/CelebA-HQ-White-Background')
    parser.add_argument('--celeba_image_dir_skt', type=str, default='/Users/ucheosahor/Documents/Data/CelebA-HQ-White-Background-Sketch')
    parser.add_argument('--cgui_image_dir_skt', type=str, default='/Users/ucheosahor/Documents/Data/test_Sketch')
    parser.add_argument('--attr_path', type=str, default='/Users/ucheosahor/Documents/Data/CelebAMask-HQ-att.txt')
    parser.add_argument('--rafd_image_dir', type=str, default='/Users/ucheosahor/Documents/Data/RaFD/train')
    parser.add_argument('--log_dir', type=str, default='/Users/ucheosahor/Documents/Data/logs')
    parser.add_argument('--model_save_dir', type=str, default='/Users/ucheosahor/Documents/Data/models')
    parser.add_argument('--sample_dir', type=str, default='/Users/ucheosahor/Documents/Data/samples')
    parser.add_argument('--result_dir', type=str, default='/Users/ucheosahor/Documents/Data/results')


    # Step size.
    parser.add_argument('--log_step', type=int, default=25)
    parser.add_argument('--sample_step', type=int, default=500)#1000
    parser.add_argument('--model_save_step', type=int, default=10000)
    parser.add_argument('--lr_update_step', type=int, default=1000)

    config = parser.parse_args()
    print(config)

    main(config)
